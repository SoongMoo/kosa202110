package school.service.professorSubject;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import school.command.ProfessorSubjectCommand;
import school.domain.AuthInfo;
import school.domain.ProfessorSubjectDTO;
import school.mapper.ProfessorSubjectMapper;

@Service
public class ProSubjectRegistService {
	@Autowired
	ProfessorSubjectMapper proSubjectMapper;
	public void execute(HttpSession session, Model model) {
		AuthInfo authInfo = (AuthInfo) session.getAttribute("authInfo");
		ProfessorSubjectDTO dto = proSubjectMapper.getProNum(authInfo.getUserId());
		model.addAttribute("professorSubjectCommand", dto);
	}
	public void execute1(ProfessorSubjectCommand professorSubjectCommand, BindingResult result) {
		ProfessorSubjectDTO dto = new ProfessorSubjectDTO();
		dto.setProfessorNum(professorSubjectCommand.getProfessorNum());
		dto.setSubjectNum(professorSubjectCommand.getSubjectNum());
		proSubjectMapper.proSubjectInsert(dto);
	}

}
