package school.service.promypage;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import school.command.ProPwChangeCommand;
import school.domain.AuthInfo;
import school.domain.ProfessorDTO;
import school.mapper.ProfessorMapper;

@Service
public class ProPwChangeService {
	@Autowired
	ProfessorMapper professorMapper;
	@Autowired
	PasswordEncoder passwordEncoder;
	public void execute(String proNum, Model model) {
		
		ProfessorDTO dto = professorMapper.selectOne(proNum);
		model.addAttribute("proPwChangeCommand", dto);
	}
	public String execute2(ProPwChangeCommand proPwChangeCommand, BindingResult result,
						HttpSession session, Model model) {
		String path = "redirect:mypageDetail";
		AuthInfo authInfo = (AuthInfo)session.getAttribute("authInfo");
		
		if (result.hasErrors()) {
			path = "thymeleaf/proMypage/proPwChange";
		}else if (!passwordEncoder.matches(proPwChangeCommand.getProPw(), authInfo.getUserPw())) {
			System.out.println("!@#@$%#$%#$%%비번 틀림띠 !@#!@#!@#!@# ");
			result.rejectValue("proPw", "proPwChangeCommand.proPw", "현재 비밀번호가 틀립니다.");
			path = "thymeleaf/proMypage/proPwChange";
		}else if (!proPwChangeCommand.getNewProPw().equals(proPwChangeCommand.getNewProPwCon())) {
			System.out.println("!@#@$%#$%#$%생로운비번이틀림띵~!!!@#!@#!@#!@# ");
			result.rejectValue("newProPw", "proPwChangeCommand.newProPw", "비밀번호와 비밀번호 확인이 일치하지 않습니다.");
			path = "thymeleaf/proMypage/proPwChange";
		}else {
			String newProPw = passwordEncoder.encode(proPwChangeCommand.getNewProPw());
			authInfo.setUserPw(newProPw);
			ProfessorDTO dto = new ProfessorDTO();
			dto.setProfessorPw(newProPw);
			dto.setProfessorId(authInfo.getUserId());
			professorMapper.proPwChange(dto);
			path = "redirect:mypageDetail";
		}
		
		return path;
	}

}
