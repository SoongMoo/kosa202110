package school.service.subject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import school.mapper.SubjectMapper;

@Component
@Service
public class SubjectDeleteService {
	@Autowired
	SubjectMapper subjectMapper;
	public void execute(String num) {
		subjectMapper.subjectDelete(num);
	}

}
