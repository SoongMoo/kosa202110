package school.service.professor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import school.domain.AuthInfo;
import school.domain.ProfessorDTO;
import school.mapper.LoginMapper;
import school.mapper.ProfessorMapper;

@Component
@Service
public class ProEmailCheckService {
	@Autowired
	ProfessorMapper professorMapper;
	public Integer execute(String professorEmail, String professorId) {
		ProfessorDTO dto = professorMapper.proEmailModiCheck(professorEmail);
		if (dto != null && dto.getProfessorId().equals(professorId)) {
			return 0;
		} else if (dto != null) {
			return 1;
		}

		else {
			return 0;
		}
	}
}
