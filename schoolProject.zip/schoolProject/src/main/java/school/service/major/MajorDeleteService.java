package school.service.major;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import school.domain.MajorDTO;
import school.mapper.MajorMapper;

@Component
@Service
public class MajorDeleteService {
	@Autowired
	MajorMapper majorMapper;
	public void execute(String num) {
		majorMapper.majorDelete(num);
	}

}
