package school.command;

import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
public class ProfessorSubjectCommand {
	String professorNum;

	@NotBlank(message = "강의를 선택하세요.")
	String subjectNum;
	String subjectName;
	String idx;

	char status;
}
