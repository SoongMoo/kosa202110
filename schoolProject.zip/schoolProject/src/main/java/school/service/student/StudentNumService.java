package school.service.student;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import school.command.StudentCommand;
import school.mapper.StudentMapper;

@Service
public class StudentNumService {
	@Autowired
	StudentMapper studentMapper;
	public String execute(String departNum) {
	 	String stuNum = studentMapper.createNum(departNum);
	 	return stuNum;
	}
	
}
