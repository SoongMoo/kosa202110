package school.command;

import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
public class StuPwChangeCommand {
	
	@NotBlank(message = "기존 비밀번호를 입력하세요")
	String stuPw;
	@NotBlank(message = "변경하실 비밀번호를 입력하세요")
	String newStuPw;
	@NotBlank(message = "변경하실 비밀번호확인를 입력하세요")
	String newStuPwCon;
	String studentId;
	
}
