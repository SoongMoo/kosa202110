package school.service.professor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import school.command.ProfessorCommand;
import school.domain.ProfessorDTO;
import school.mapper.ProfessorMapper;

@Component
@Service
public class ProfessorAutoNumService {
	@Autowired
	ProfessorMapper professorMapper;
	public void execute(ProfessorCommand professorCommand) {
		String autoNum = professorMapper.autoNum();
		ProfessorDTO dto = new ProfessorDTO();
		dto.setProfessorNum(autoNum);
		professorCommand.setProfessorNum(autoNum);
	}
}
