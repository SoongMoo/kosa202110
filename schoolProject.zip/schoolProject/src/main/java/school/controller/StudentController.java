package school.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import school.command.StudentCommand;
import school.service.major.MajorListService;
import school.service.student.StuEmailCheckService;
import school.service.student.StuIdCheckService;
import school.service.student.StuModifyEmailService;
import school.service.student.StudentAutoNumService;
import school.service.student.StudentDeleteService;
import school.service.student.StudentDetailService;
import school.service.student.StudentListService;
import school.service.student.StudentModifyService;
import school.service.student.StudentRegistService;
import school.service.student.StudentUpdateService;

@Controller
@RequestMapping(value="student")
public class StudentController {
	@Autowired
	StudentRegistService studentRegistService;
	@Autowired
	MajorListService majorListService;
	@Autowired
	StudentAutoNumService studentAutoNumService;
	@Autowired
	StudentListService studentListService;
	@Autowired
	StudentDetailService studentDetailService;
	@Autowired
	StudentModifyService studentModifyService;
	@Autowired
	StudentUpdateService studentUpdateService;
	@Autowired
	StudentDeleteService studentDeleteService;
	@Autowired
	StuIdCheckService stuIdCheckService;
	@Autowired
	StuEmailCheckService stuEmailCheckService;
	@Autowired
	StuModifyEmailService stuModifyEmailService;
	
	
	@RequestMapping(value="studentDelete")
	public String studentDelete(@RequestParam(value="id") String id) {
		studentDeleteService.execute(id);
		return "redirect:studentList";
	}
	
	
	@RequestMapping(value="studentUpdate")
	public String studentUpdate(@Validated StudentCommand studentCommand, BindingResult result,  Model model, HttpSession session,
								@RequestParam(value="page", defaultValue = "1", required = false)Integer page, 
								@RequestParam(value = "majorWord" , required = false)String majorWord) {
		String path = "";
		majorListService.execute(majorWord, page, model);
		Integer i = stuModifyEmailService.execute(studentCommand.getStudentEmail(), studentCommand.getStudentId());
		if (i==1) {
			result.rejectValue("studentEmail", "studentCommand.studentEmail", "이미 존재하는 이메일입니다.");
			return "thymeleaf/student/studentModify";
		}
		path = studentUpdateService.execute(studentCommand, model, result);
		return path;
	}
	@RequestMapping(value = "studentModify")
	public String studentModify(@RequestParam(value="id") String id, Model model ,
								@RequestParam(value="page", defaultValue = "1", required = false)  Integer page,
								@RequestParam(value = "majorWord" , required = false)String majorWord) {
		majorListService.execute(majorWord, page, model);
		studentModifyService.execute(id, model);
		return "thymeleaf/student/studentModify";
	}
	@RequestMapping(value="studentDetail")
	public String studentDetail(@RequestParam(value="id") String id, Model model) {
		studentDetailService.execute(id, model);
		return "thymeleaf/student/studentDetail";
	}
	@RequestMapping(value="studentRegist", method = RequestMethod.POST)
	public String studentRegist2(@Validated StudentCommand studentCommand, BindingResult result, Model model,
								 @RequestParam(value="page", defaultValue = "1", required = false)Integer page,
								 @RequestParam(value = "majorWord" , required = false)String majorWord) {
		majorListService.execute(majorWord,page, model);
		if(result.hasErrors()) {
			return "thymeleaf/student/studentForm";
		}
		Integer i = stuIdCheckService.execute(studentCommand.getStudentId());
		if (i == 1) {
			result.rejectValue("studentId", "studentCommand.studentId", "이미 사용중인 아이디입니다.");
			return "thymeleaf/student/studentForm";
		}
		i = stuEmailCheckService.execute(studentCommand.getStudentEmail());
		if (i == 1) {
			result.rejectValue("studentEmail", "studentCommand.studentEmail", "이미 사용중인 이메일입니다.");
			return "thymeleaf/student/studentForm";
		}
		if(!studentCommand.getStudentPw().equals(studentCommand.getStudentPwCon())) {
			result.rejectValue("studentPw", "studentCommand.studentPw", "비밀번호와 비밀번호 확인이 다릅니다.");
			return "thymeleaf/student/studentForm";
		}
		studentRegistService.execute(studentCommand, model);
		return "thymeleaf/student/studentAlert";
	}
	@RequestMapping(value="studentRegist", method = RequestMethod.GET)
	public String studentRegist(Model model, StudentCommand studentCommand,
								@RequestParam(value="page", defaultValue = "1", required = false)Integer page,
								@RequestParam(value = "majorWord" , required = false)String majorWord) {
		majorListService.execute(majorWord,page, model);
		return "thymeleaf/student/studentForm";
	}
	@RequestMapping("studentList")
	public String studentList(@RequestParam(value="page", defaultValue = "1", required = false) Integer page, Model model,
							  @RequestParam(value="studentWord", required = false) String studentWord) {
		studentListService.execute(studentWord, page, model);
		return "thymeleaf/student/studentList";
	}
}
