package school.service.professorSubject;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import school.command.ProfessorSubjectCommand;
import school.mapper.ProfessorSubjectMapper;

@Service
public class ProSubDoubleService {
	@Autowired
	ProfessorSubjectMapper professorSubjectMapper;
	public Integer execute(ProfessorSubjectCommand professorSubjectCommand) {
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("proNum", professorSubjectCommand.getProfessorNum());
		map.put("subNum", professorSubjectCommand.getSubjectNum());
		
		String existSub = professorSubjectMapper.subExist(map);
		if (existSub != null) {
			return 1;
		}else return 0;
	}
}
