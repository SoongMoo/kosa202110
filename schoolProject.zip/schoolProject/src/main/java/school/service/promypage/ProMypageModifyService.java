package school.service.promypage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import school.domain.ProfessorDTO;
import school.mapper.ProfessorMapper;

@Service
public class ProMypageModifyService {
	@Autowired
	ProfessorMapper professorMapper;
	public void execute(String num, Model model) {
		ProfessorDTO dto = professorMapper.getDepartName(num);
		model.addAttribute("professorCommand",dto);
	}

}
