package school.mapper;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import school.domain.StartEndPageDTO;
import school.domain.StudentDTO;

@Component
@Repository(value="school.mapper.StudentMapper")
public interface StudentMapper {
	public String autoNum();
	public Integer studentInsert(StudentDTO dto);
	public List<StudentDTO> selectAll(StartEndPageDTO dto);
	public Integer count(String studentWord);
	public StudentDTO selectOne(String id);
	public Integer studentUpdate(StudentDTO dto);
	public Integer studentDelete(String id);
	public String createNum(String departNum);
	public String idDoubleCheck(String id);
	public String emailDoubleCheck(String email);
	public StudentDTO stuEmailModiCheck(String email);
	public StudentDTO getDepartName(String stuNum);
}
