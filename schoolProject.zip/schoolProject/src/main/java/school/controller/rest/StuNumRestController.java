package school.controller.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import school.command.StudentCommand;
import school.service.student.StudentNumService;

@RestController
public class StuNumRestController {
	@Autowired
	StudentNumService studentNumService;
	
	@RequestMapping(value="/student/stuNum")
	public String stuNum(String departNum) {
		String result = studentNumService.execute(departNum);
		return result;
	}
}
