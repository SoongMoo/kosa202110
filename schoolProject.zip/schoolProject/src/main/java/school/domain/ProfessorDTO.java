package school.domain;

import org.apache.ibatis.type.Alias;

import lombok.Data;

@Data
@Alias(value="professorDTO")
public class ProfessorDTO {
	String professorNum;
	String professorName;
	String professorPhone;
	String professorEmail;
	String professorId;
	String professorPw;
	String departmentNum;
	String departmentName;
	String proPw;
	String newProPw;
	String newProPwCon;

}
