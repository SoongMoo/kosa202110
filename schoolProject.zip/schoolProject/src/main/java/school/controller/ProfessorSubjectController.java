package school.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import school.command.ProfessorSubjectCommand;
import school.service.professorSubject.ListService;
import school.service.professorSubject.MySubjectDeleteService;
import school.service.professorSubject.MySubjectListService;
import school.service.professorSubject.ProSubDoubleService;
import school.service.professorSubject.ProSubjectRegistService;
import school.service.professorSubject.StatusModifyService;
import school.service.subject.SubjectListService;

@Controller
@RequestMapping("professorSubject")
public class ProfessorSubjectController {
	@Autowired
	ProSubjectRegistService proSubjectRegistService;
	@Autowired
	SubjectListService subjectListService;
	@Autowired
	MySubjectListService mySubjectListService;
	@Autowired
	MySubjectDeleteService mySubjectDeleteService;
	@Autowired
	StatusModifyService statusModifyService;
	@Autowired
	ProSubDoubleService proSubDoubleService;
	@Autowired
	ListService listService;

	@RequestMapping("statusModifyToNull")
	public @ResponseBody void statusModifyToNull(String subNum, String proNum) {
		statusModifyService.execute1(subNum, proNum);
	}
	
	@RequestMapping("statusModifyTo1")
	public @ResponseBody void statusModify(String subNum, String proNum) {
		statusModifyService.execute(subNum, proNum);
	}
	@RequestMapping("mySubjectDelete")
	public @ResponseBody String mySubjectDelete(String subNum, String proNum) {
		Integer i = mySubjectDeleteService.execute(subNum, proNum);
		return i.toString();
	}
	@RequestMapping("mySubjectList")
	public String mySubjectList(HttpSession session, Model model,
								@RequestParam(value="page", defaultValue = "1", required = false) Integer page) {
		mySubjectListService.execute(session, model, page);
		return "thymeleaf/professorSubject/mySubjectList";
	}
	@RequestMapping(value="proSubjectRegist", method = RequestMethod.POST)
	public String proSubjectRegist1(@Validated ProfessorSubjectCommand professorSubjectCommand, 
									BindingResult result, Model model) {
		listService.execute(model);
		Integer i = proSubDoubleService.execute(professorSubjectCommand);
		if(i==1) {
			result.rejectValue("subjectNum", "dto.subjectNum", "이미 등록한 강의입니다.");
			return "thymeleaf/professorSubject/proSubjectForm";
		}
		proSubjectRegistService.execute1(professorSubjectCommand, result);
		return "redirect:proSubjectList";
	}
	@RequestMapping(value="proSubjectRegist", method = RequestMethod.GET)
	public String proSubjectRegist(
									HttpSession session, Model model) {
		listService.execute(model);
		proSubjectRegistService.execute(session, model);
		return "thymeleaf/professorSubject/proSubjectForm";
	}
	@RequestMapping("proSubjectList")
	public String proSubjectList() {
		return "thymeleaf/professorSubject/proSubjectList";
	}
}
