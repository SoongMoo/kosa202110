package school.service.professorSubject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import school.domain.ProfessorSubjectDTO;
import school.mapper.ProfessorSubjectMapper;

@Service
public class StatusModifyService {
	@Autowired
	ProfessorSubjectMapper professorSubjectMapper;	
	//폐강하기
	public void execute(String subNum, String proNum) {
		ProfessorSubjectDTO dto = new ProfessorSubjectDTO();
		dto.setProfessorNum(proNum);
		dto.setSubjectNum(subNum);
		professorSubjectMapper.statusUpdateTo1(dto);
	}
	//폐강취소하기
	public void execute1(String subNum, String proNum) {
		ProfessorSubjectDTO dto = new ProfessorSubjectDTO();
		dto.setProfessorNum(proNum);
		dto.setSubjectNum(subNum);
		professorSubjectMapper.statusUpdateToNull(dto);
	}

}
