package school.controller;

import org.junit.runners.Parameterized.BeforeParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import school.command.SubjectCommand;
import school.service.subject.AutoNumService;
import school.service.subject.SubjectDeleteService;
import school.service.subject.SubjectDetailService;
import school.service.subject.SubjectListService;
import school.service.subject.SubjectRegistService;
import school.service.subject.SubjectUpdateservice;

@RequestMapping("subject")
@Controller
public class SubjectController {
	@Autowired
	AutoNumService autoNumService;
	@Autowired
	SubjectRegistService subjectRegistService;
	@Autowired
	SubjectListService subjectListService;
	@Autowired
	SubjectUpdateservice subjectUpdateservice;
	@Autowired
	SubjectDeleteService subjectDeleteService;
	@Autowired
	SubjectDetailService subjectDetailService;
	
	
	@RequestMapping("subjectDetail")
	public String subjectDetail(@RequestParam(value="subNum") String num,  Model model) {
		model.addAttribute("newLineChar" , "\n");
		subjectDetailService.execute(num, model);
		return "thymeleaf/subject/subjectDetail";
	}
	@RequestMapping("subjectDelete")
	public String subjectDelete(@RequestParam(value="subNum") String num) {
		subjectDeleteService.execute(num);
		return "redirect:subList";
	}
	
	@RequestMapping("subjectUpdate")
	public String subjectUpdate(SubjectCommand subjectCommand) {
		subjectUpdateservice.execute2(subjectCommand);
		return "redirect:subList";
	}
	@RequestMapping("subjectModify")
	public String subjectModify(@RequestParam(value="subNum") String num , Model model) {
		subjectUpdateservice.execute(num, model);
		return "thymeleaf/subject/subjectModify";
	}
	@RequestMapping("subjectRegist")
	public String subjectRegist(SubjectCommand subjectCommand) {
		subjectRegistService.execute(subjectCommand);
		return "redirect:subList";
	}
	@RequestMapping("subjectForm")
	public String subjectForm(Model model) {
		autoNumService.execute(model);
		return "thymeleaf/subject/subjectForm";
	}
	@RequestMapping("subList")
	public String subList(@RequestParam(value="page", defaultValue = "1", required = false) Integer page, Model model,
					      @RequestParam(value="subjectWord", required=false)String subjectWord) {
		subjectListService.execute(subjectWord, page, model);
		return "thymeleaf/subject/subList";
	}
	
}
