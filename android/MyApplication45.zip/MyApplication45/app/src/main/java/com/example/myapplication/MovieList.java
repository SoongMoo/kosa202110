package com.example.myapplication;

public class MovieList {
    MovieListResult boxOfficeResult;
}
