package school.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import school.command.LoginCommand;
import school.service.LoginService;

@RequestMapping("login")
@Controller
public class LoginController {
	@Autowired
	LoginService loginService;

	@RequestMapping(value = "loginPro", method = RequestMethod.GET)
	public String home() {
		return "redirect:/";
	}
	@RequestMapping(value = "loginPro", method = RequestMethod.POST)
	public String loginPro(@Validated LoginCommand loginCommand ,
			BindingResult result, HttpSession session, HttpServletResponse response, HttpServletRequest request) {
		if(result.hasErrors()) {
			System.out.println("!@#$$%#$^#%^%##^%^%#");
			return "thymeleaf/index";
		}
		String path = loginService.execute(loginCommand, result, request, session, response);
		return "redirect:/";
	}
	@RequestMapping("logout")
	public String logout(HttpSession session , HttpServletResponse response) {
		Cookie cookie = new Cookie("autoLogin","");
		cookie.setPath("/");
		cookie.setMaxAge(0);
		response.addCookie(cookie);
		
		session.invalidate();
		return "redirect:/";
	}
}