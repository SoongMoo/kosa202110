package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText edit1, edit2;
    TextView textResult;
    String num1 ,num2;
    Integer result;
    Button btn[] = new Button[4];
    Integer [] btnIds = {R.id.BtnAdd, R.id.BtnSub, R.id.BtnMul,
            R.id.BtnDiv};
    Button[] numButtons = new Button[10];
    Integer[] numBtnIDs = {R.id.BtnNum0,R.id.BtnNum1, R.id.BtnNum2,
            R.id.BtnNum3, R.id.BtnNum4, R.id.BtnNum5, R.id.BtnNum6,
            R.id.BtnNum7, R.id.BtnNum8, R.id.BtnNum9 };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("그리드레이아웃 계산기");
        edit1 = (EditText)findViewById(R.id.Edit1);
        edit2 = (EditText) findViewById(R.id.Edit2);
        textResult = (TextView) findViewById(R.id.TextResult);
        for(int i = 0; i <btn.length; i++){
            btn[i] = (Button)findViewById(btnIds[i]);
        }
        for(int i = 0; i < numButtons.length ; i++){
            numButtons[i]=(Button) findViewById(numBtnIDs[i]);
        }
        for(int i = 0; i < numButtons.length; i++){
            final int idx;
            idx = i;
            numButtons[idx].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(edit1.isFocused()){
                        num1 = edit1.getText().toString()
                                + numButtons[idx].getText().toString();
                        edit1.setText(num1);
                    }else if(edit2.isFocused()){
                        num2 = edit2.getText().toString()
                                + numButtons[idx].getText().toString();
                        edit2.setText(num2);
                    }else{
                        Toast.makeText(getApplicationContext(),
                                "먼저 에디트텍스트를 선택하세요",
                                Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
        for(int i = 0; i <btn.length; i++){
            final int idx;
            idx = i;
            btn[idx].setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View view, MotionEvent motionEvent) {
                    num1 = edit1.getText().toString();
                    num2 = edit2.getText().toString();
                    switch (btn[idx].getText().toString()){
                        case "더하기":
                            result = Integer.parseInt(num1) + Integer.parseInt(num2);
                            break;
                        case "빼기":
                            result = Integer.parseInt(num1) - Integer.parseInt(num2);
                            break;
                        case "곱하기":
                            result = Integer.parseInt(num1) * Integer.parseInt(num2);
                            break;
                        case "나누기":
                            result = Integer.parseInt(num1) / Integer.parseInt(num2);
                            break;
                    }
                    textResult.setText("계산 결과 : " + result.toString());
                    return false;
                }
            });
        }
    }
}