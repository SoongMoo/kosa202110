package school.service.subject;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import school.domain.StartEndPageDTO;
import school.domain.SubjectDTO;
import school.mapper.SubjectMapper;

@Component
@Service
public class SubjectListService {
	@Autowired
	SubjectMapper subjectMapper;
	public void execute(String subjectWord, Integer page, Model model) {
		int limit = 5; // 보인느 게시글의 수 
		int limitPage = 3; // 보이는 페이지의 수 
		
		Long startRow = ((long)page-1)*limit + 1;
		Long endRow = startRow + limit -1;
		StartEndPageDTO dto = new StartEndPageDTO();
		dto.setStartRow(startRow);
		dto.setEndRow(endRow);
		dto.setSubjectWord(subjectWord);
		
		int count = subjectMapper.count(subjectWord);
		int maxPage = (int)((double)count/limit +0.9);
		int startPage = ((int)((double)page /limitPage+0.9) -1) *limitPage +1;
		int endPage = startPage + limitPage -1;
		if(endPage > maxPage) endPage = maxPage;
		
		List<SubjectDTO> list = subjectMapper.selectAll(dto);
		
		model.addAttribute("maxPage" , maxPage);
		model.addAttribute("startPage" , startPage);
		model.addAttribute("endPage" , endPage);
		model.addAttribute("page" , page);
		model.addAttribute("list", list);
		model.addAttribute("subjectWord", subjectWord);
	}
}
