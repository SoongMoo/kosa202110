package school.service.student;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import school.domain.StudentDTO;
import school.mapper.StudentMapper;

@Service
public class StuModifyEmailService {
	@Autowired
	StudentMapper studentMapper;
	public Integer execute(String studentEmail, String studentId) {
		StudentDTO dto =  studentMapper.stuEmailModiCheck(studentEmail);
		if (dto!=null && dto.getStudentId().equals(studentId)) {
			return 0;
		}else if (dto!=null){
			return 1;
		}else return 0;
	}

}
