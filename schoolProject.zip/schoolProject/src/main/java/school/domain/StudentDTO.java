package school.domain;

import org.apache.ibatis.type.Alias;

import lombok.Data;

@Data
@Alias("studentDTO")
public class StudentDTO {
	String studentNum;
	String studentName;
	String studentPhone;
	String studentEmail;
	String studentId;
	String studentPw;
	String departmentNum;
	String departmentName;
	String stuPw;
	String newStuPw;
	String newStuPwCon;
}
