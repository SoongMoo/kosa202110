package school.service.student;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import school.command.StudentCommand;
import school.domain.AuthInfo;
import school.domain.StudentDTO;
import school.mapper.StudentMapper;
@Service
public class StudentUpdateService {
	@Autowired
	StudentMapper studentMapper;
	@Autowired
	PasswordEncoder passwordEncoder;
	public String execute( StudentCommand studentCommand, Model model, BindingResult result) {
		String path = "redirect:studentDetail?id="+studentCommand.getStudentId();
		// 학생 아이디에 대한 정보
		StudentDTO dto1 = studentMapper.selectOne(studentCommand.getStudentId());
		if (result.hasErrors()) {
			return "thymeleaf/student/studentModify";
		}
		// 학생의 pw와 입력한 pw가 같을 때만 수정
		else if (!passwordEncoder.matches(studentCommand.getStudentPw(), dto1.getStudentPw())) {
			result.rejectValue("studentPw", "studentCommand.studentPw", "비밀번호가 일치하지 않습니다.");
			return "thymeleaf/student/studentModify";
		}else {
			StudentDTO dto = new StudentDTO();
			dto.setDepartmentNum(studentCommand.getDepartmentNum());
			dto.setStudentEmail(studentCommand.getStudentEmail());
			dto.setStudentName(studentCommand.getStudentName());
			dto.setStudentPhone(studentCommand.getStudentPhone());
			dto.setStudentNum(studentCommand.getStudentNum());
			dto.setStudentId(studentCommand.getStudentId());
			studentMapper.studentUpdate(dto);
			model.addAttribute("dto", dto);
			
		}
		return path;

	}

}
