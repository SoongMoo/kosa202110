package school.service.professorSubject;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import school.domain.SubjectDTO;
import school.mapper.SubjectMapper;

@Service
public class ListService {
	@Autowired
	SubjectMapper subjectMapper;
	public void execute(Model model) {
		List<SubjectDTO> list = subjectMapper.All();
		model.addAttribute("list", list);
	}
	
}
