package school.mapper;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import school.domain.StartEndPageDTO;
import school.domain.SubjectDTO;

@Component
@Repository(value="sschool.mapper.SubjectMapper")
public interface SubjectMapper {
	public String autoNum();
	public Integer subjectInsert(SubjectDTO dto);
	public List<SubjectDTO> selectAll(StartEndPageDTO dto );
	public SubjectDTO selectOne(String num);
	public Integer subjectUpdate(SubjectDTO dto);
	public Integer subjectDelete(String num);
	public Integer count(String subjectWord);
	public List<SubjectDTO> All();
}
