package school.service.major;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import school.command.MajorCommand;
import school.domain.MajorDTO;
import school.mapper.MajorMapper;

@Component
@Service
public class MajorUpdateService {
	@Autowired
	MajorMapper majorMapper;
	public void execute(String num, Model model) {
		MajorDTO dto = majorMapper.selectOne(num);
		model.addAttribute("dto", dto);
	}
	public void execute2(MajorCommand majorCommand) {
		MajorDTO dto = new MajorDTO();
		dto.setDepartmentName(majorCommand.getMajorName());
		dto.setDepartmentAddr(majorCommand.getMajorAddr());
		dto.setDepartmentPhone(majorCommand.getMajorPhone());
		dto.setDepartmentNum(majorCommand.getMajorNum());

		dto.setAddr1(majorCommand.getAddr1());
		dto.setAddr2(majorCommand.getAddr2());
		dto.setFullAddr(majorCommand.getFullAddr());
		dto.setZip(majorCommand.getZip());
		majorMapper.majorUpdate(dto);
		
	}
}
