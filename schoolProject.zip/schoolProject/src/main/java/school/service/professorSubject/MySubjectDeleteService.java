package school.service.professorSubject;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import school.mapper.ProfessorSubjectMapper;
@Service
public class MySubjectDeleteService {
	@Autowired
	ProfessorSubjectMapper professorSubjectMapper;
	public Integer execute(String subNum, String proNum) {
		HashMap<String, String> map = new HashMap<String, String>(); 
		map.put("sNum", subNum);
		map.put("pNum", proNum);
		try {
			return professorSubjectMapper.mySubjectDelete(map);
		}catch(Exception e) {
			return 0;
		}
		
	}

}
