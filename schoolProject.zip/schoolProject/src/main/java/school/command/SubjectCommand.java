package school.command;

import lombok.Data;

@Data
public class SubjectCommand {
	String subjectNum;
	String subjectName;
	String subjectTitle;
	String subjectContent;
}
