package school.command;

import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
public class ProPwChangeCommand {
	
	@NotBlank(message = "기존 비밀번호를 입력하세요")
	String proPw;
	@NotBlank(message = "변경하실 비밀번호를 입력하세요")
	String newProPw;
	@NotBlank(message = "변경하실 비밀번호확인를 입력하세요")
	String newProPwCon;
	String professorNum;
	
}
