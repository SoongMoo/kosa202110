package school.service.stumypage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import school.domain.StudentDTO;
import school.mapper.StudentMapper;

@Service
public class StuMypageModifyService {
	@Autowired
	StudentMapper studentMapper;
	public void execute(String id, Model model) {
		StudentDTO dto = studentMapper.selectOne(id);
		StudentDTO dto1 = studentMapper.getDepartName(dto.getStudentNum());
		model.addAttribute("studentCommand", dto);
		model.addAttribute("studentCommand", dto1);
		
		
	}
	
}
