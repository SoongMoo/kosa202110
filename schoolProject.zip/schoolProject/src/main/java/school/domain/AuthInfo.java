package school.domain;

import org.apache.ibatis.type.Alias;

import lombok.Data;

@Data
@Alias(value="authInfo")
public class AuthInfo {
	String userNum;
	String userName;
	String userPhone;
	String userEmail;
	String userId;
	String userPw;
	String grade;
	String userDepartmentNum;
}
