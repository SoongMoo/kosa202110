package school.service.stumypage;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import school.command.StuPwChangeCommand;
import school.domain.AuthInfo;
import school.domain.StudentDTO;
import school.mapper.StudentMapper;
@Service
public class StuPwChangeService {
	@Autowired
	StudentMapper studentMapper;
	@Autowired
	PasswordEncoder passwordEncoder;
	public void execute(String stuNum, Model model) {
		StudentDTO dto =studentMapper.getDepartName(stuNum);
		model.addAttribute("stuPwChangeCommand",dto);
	}
	public String execute2(StuPwChangeCommand stuPwChangeCommand, BindingResult result, HttpSession session,
			Model model) {
		String path = "redirect:mypageDetail";
		
		AuthInfo authInfo = (AuthInfo)session.getAttribute("authInfo");
		if (result.hasErrors()) {
			path = "thymeleaf/stuMypage/stuPwChange";
		}else if (!passwordEncoder.matches(stuPwChangeCommand.getStuPw(), authInfo.getUserPw())) {
			result.rejectValue("stuPw", "stuPwChangeCommand.stuPw", "현재 비밀번호가 일치하지 않습니다.");
			path = "thymeleaf/stuMypage/stuPwChange";
		}else if (!stuPwChangeCommand.getNewStuPw().equals(stuPwChangeCommand.getNewStuPwCon())) {
			result.rejectValue("newStuPw", "stuPwChangeCommand.newStuPw", "새로운 비밀번호와 비밀번호 확인이 일치하지 않습니다.");
			path = "thymeleaf/stuMypage/stuPwChange";
		}else {
			String newProPw = passwordEncoder.encode(stuPwChangeCommand.getNewStuPw());
			authInfo.setUserPw(newProPw);
			StudentDTO dto = studentMapper.selectOne(authInfo.getUserId());
			dto.setStudentPw(passwordEncoder.encode(stuPwChangeCommand.getNewStuPw()));
			dto.setStudentId(stuPwChangeCommand.getStudentId());
			studentMapper.studentUpdate(dto);
		}
		return path;
	}

}



