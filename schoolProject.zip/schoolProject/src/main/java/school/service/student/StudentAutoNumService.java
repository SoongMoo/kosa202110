package school.service.student;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import school.domain.StudentDTO;
import school.mapper.StudentMapper;

@Service
public class StudentAutoNumService {
	@Autowired
	StudentMapper studentMapper;
	public String execute() {
		String auto = studentMapper.autoNum();
		return auto;
		
	}
}
