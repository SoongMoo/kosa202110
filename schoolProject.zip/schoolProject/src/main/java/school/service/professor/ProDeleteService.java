package school.service.professor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import school.mapper.ProfessorMapper;

@Component
@Service
public class ProDeleteService {
	@Autowired
	ProfessorMapper professorMapper;
	public void execute(String num) {
		professorMapper.professorDelete(num);
	}
}
