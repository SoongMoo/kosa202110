package school.service.subject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import school.command.SubjectCommand;
import school.domain.SubjectDTO;
import school.mapper.SubjectMapper;

@Component
@Service
public class SubjectUpdateservice {
	@Autowired
	SubjectMapper subjectMapper;
	public void execute(String num, Model model) {
		SubjectDTO dto = subjectMapper.selectOne(num);
		model.addAttribute("dto", dto);
	}
	public void execute2(SubjectCommand subjectCommand) {
		SubjectDTO dto = new SubjectDTO();
		dto.setSubjectContent(subjectCommand.getSubjectContent());
		dto.setSubjectName(subjectCommand.getSubjectName());
		dto.setSubjectNum(subjectCommand.getSubjectNum());
		dto.setSubjectTitle(subjectCommand.getSubjectTitle());
	
		subjectMapper.subjectUpdate(dto);
	}
	
}
