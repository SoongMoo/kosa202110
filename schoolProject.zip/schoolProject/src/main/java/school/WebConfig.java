package school;


import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
// extends로 하면 adapter 로 만들어짐 : 클래스상속
// implements 는 interface 상속 
public class WebConfig implements WebMvcConfigurer{	
	
	// html이나 jsp문서 그리고 이미지파일인 경우 view밑에 있는 파일을 불러 올때 404오류가 나는 것을 방지
	@Override
	public void addResourceHandlers(
			ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/**")
                .addResourceLocations("/view/")
                .setCachePeriod(14400);
	}
	
	// validation 에 대한 오류 메세지 
	// resourse폴더 밑에 message 밑에 error.properties가 있어야 한다. 
	@Bean
	public ResourceBundleMessageSource messageSource() {
		ResourceBundleMessageSource source= new ResourceBundleMessageSource();
		source.setBasenames("message/error"); // error.properties
		source.setUseCodeAsDefaultMessage(true);
		source.setDefaultEncoding("utf-8");
		return source;
	}
	
  
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		// TODO Auto-generated method stub
		//List<String> list = new ArrayList<String>();
		//list.add("/static/**/*");
		///list.add("/register/**/*");
		//list.add("/help/**/*");
		//list.add("/login/**/*");
		//list.add("/corner/**/*");
		//registry.addInterceptor(new CertificationInterceptor())
		//        .addPathPatterns("/**/*") //모든 주소
    	//	      .excludePathPatterns(list);
		// 로그인 세션이 없어도 되는 주소들을 적어 준다.
	}
	


	
}