package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
  //
    EditText edit1, edit2;
    Button btnAdd, btnSub, btnMul, btnDiv;
    TextView textResult;
    String num1 ,num2;
    Integer result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("테이블레이아웃 계산기");
        Integer edt1 = R.id.Edit1;
        edit1 = (EditText)findViewById(edt1);
        edit2 = (EditText) findViewById(R.id.Edit2);
        btnAdd = (Button) findViewById(R.id.BtnAdd);
        btnSub = (Button) findViewById(R.id.BtnSub);
        btnMul = (Button) findViewById(R.id.BtnMul);
        btnDiv = (Button) findViewById(R.id.BtnDiv);
        textResult = (TextView) findViewById(R.id.TextResult);

        Button btn[] = new Button[4];
        Integer [] btnIds = {R.id.BtnAdd, R.id.BtnSub, R.id.BtnMul,
                R.id.BtnDiv};
        for(int i = 0; i <btn.length; i++){
            btn[i] = (Button)findViewById(btnIds[i]);
        }

        for(int i = 0; i <btn.length; i++){
            final int idx;
            idx = i;
            btn[idx].setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View view, MotionEvent motionEvent) {
                    num1 = edit1.getText().toString();
                    num2 = edit2.getText().toString();
                    switch (btn[idx].getText().toString()){
                        case "더하기":
                            result = Integer.parseInt(num1) + Integer.parseInt(num2);
                            break;
                        case "빼기":
                            result = Integer.parseInt(num1) - Integer.parseInt(num2);
                            break;
                        case "곱하기":
                            result = Integer.parseInt(num1) * Integer.parseInt(num2);
                            break;
                        case "나누기":
                            result = Integer.parseInt(num1) / Integer.parseInt(num2);
                            break;
                   }
                    textResult.setText("계산 결과 : " + result.toString());
                    return false;
                }
            });
        }

        Button numButtons0 = (Button) findViewById(R.id.BtnNum0);
        Button numButtons1 = (Button) findViewById(R.id.BtnNum1);
        Button numButtons2 = (Button) findViewById(R.id.BtnNum2);
        Button numButtons3 = (Button) findViewById(R.id.BtnNum3);
        Button numButtons4 = (Button) findViewById(R.id.BtnNum4);
        Button numButtons5 = (Button) findViewById(R.id.BtnNum5);
        Button numButtons6 = (Button) findViewById(R.id.BtnNum6);
        Button numButtons7 = (Button) findViewById(R.id.BtnNum7);
        Button numButtons8 = (Button) findViewById(R.id.BtnNum8);
        Button numButtons9 = (Button) findViewById(R.id.BtnNum9);

        Button[] numButtons = new Button[10];
        Integer[] numBtnIDs = {R.id.BtnNum0,R.id.BtnNum1, R.id.BtnNum2,
                R.id.BtnNum3, R.id.BtnNum4, R.id.BtnNum5, R.id.BtnNum6,
                R.id.BtnNum7, R.id.BtnNum8, R.id.BtnNum9 };
        for(int i = 0; i < numButtons.length ; i++){
            numButtons[i]=(Button) findViewById(numBtnIDs[i]);
        }
        // 0 : numButtons[0], 1: numButtons[1], 2:numButtons[2]
        // ,...,
        // 8 : numButtons[8], 9: numButtons[9]
        /*
        btnAdd.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                num1 = edit1.getText().toString();
                num2 = edit2.getText().toString();
                result = Integer.parseInt(num1) + Integer.parseInt(num2);
                textResult.setText("계산 결과 : " + result.toString());
                return false;
            }
        });
        btnSub.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                num1 = edit1.getText().toString();
                num2 = edit2.getText().toString();
                result = Integer.parseInt(num1) - Integer.parseInt(num2);
                textResult.setText("계산 결과 : " + result.toString());
                return false;
            }
        });
        btnMul.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                num1 = edit1.getText().toString();
                num2 = edit2.getText().toString();
                result = Integer.parseInt(num1) * Integer.parseInt(num2);
                textResult.setText("계산 결과 : " + result.toString());
                return false;
            }
        });
        btnDiv.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                num1 = edit1.getText().toString();
                num2 = edit2.getText().toString();
                result = Integer.parseInt(num1) / Integer.parseInt(num2);
                textResult.setText("계산 결과 : " + result.toString());
                return false;
            }
        });
         */
        for(int i = 0; i < numButtons.length; i++){
            final int idx ; // 안드로이드에서는 배열의 index를 사용할 때 꼭 정의
            idx = i;
            numButtons[idx].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(edit1.isFocused()){
                        num1 = edit1.getText().toString()
                                + numButtons[idx].getText().toString();
                        edit1.setText(num1);
                    }else if(edit2.isFocused()){
                        num2 = edit2.getText().toString()
                                + numButtons[idx].getText().toString();
                        edit2.setText(num2);
                    }else{
                        Toast.makeText(getApplicationContext(),
                                "먼저 에디트텍스트를 선택하세요",
                                Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        /*
        numButtons0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edit1.isFocused()){
                    num1 = edit1.getText().toString()
                            + numButtons0.getText().toString();
                    edit1.setText(num1);
                }else if(edit2.isFocused()){
                    num2 = edit2.getText().toString()
                            + numButtons0.getText().toString();
                    edit2.setText(num2);
                }
            }
        });
        numButtons1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edit1.isFocused()){
                    num1 = edit1.getText().toString()
                            + numButtons1.getText().toString();
                    edit1.setText(num1);
                }else if(edit2.isFocused()){
                    num2 = edit2.getText().toString()
                            + numButtons1.getText().toString();
                    edit2.setText(num2);
                }

            }
        });
        numButtons2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edit1.isFocused()){
                    num1 = edit1.getText().toString()
                            + numButtons2.getText().toString();
                    edit1.setText(num1);
                }else if(edit2.isFocused()){
                    num2 = edit2.getText().toString()
                            + numButtons2.getText().toString();
                    edit2.setText(num2);
                }

            }
        });
        numButtons3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edit1.isFocused()){
                    num1 = edit1.getText().toString()
                            + numButtons3.getText().toString();
                    edit1.setText(num1);
                }else if(edit2.isFocused()){
                    num2 = edit2.getText().toString()
                            + numButtons3.getText().toString();
                    edit2.setText(num2);
                }

            }
        });
        numButtons4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edit1.isFocused()){
                    num1 = edit1.getText().toString()
                            + numButtons4.getText().toString();
                    edit1.setText(num1);
                }else if(edit2.isFocused()){
                    num2 = edit2.getText().toString()
                            + numButtons4.getText().toString();
                    edit2.setText(num2);
                }

            }
        });
        numButtons5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edit1.isFocused()){
                    num1 = edit1.getText().toString()
                            + numButtons5.getText().toString();
                    edit1.setText(num1);
                }else if(edit2.isFocused()){
                    num2 = edit2.getText().toString()
                            + numButtons5.getText().toString();
                    edit2.setText(num2);
                }

            }
        });
        numButtons6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edit1.isFocused()){
                    num1 = edit1.getText().toString()
                            + numButtons6.getText().toString();
                    edit1.setText(num1);
                }else if(edit2.isFocused()){
                    num2 = edit2.getText().toString()
                            + numButtons6.getText().toString();
                    edit2.setText(num2);
                }

            }
        });
        numButtons7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edit1.isFocused()){
                    num1 = edit1.getText().toString()
                            + numButtons7.getText().toString();
                    edit1.setText(num1);
                }else if(edit2.isFocused()){
                    num2 = edit2.getText().toString()
                            + numButtons7.getText().toString();
                    edit2.setText(num2);
                }
            }
        });
        numButtons8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edit1.isFocused()){
                    num1 = edit1.getText().toString()
                            + numButtons8.getText().toString();
                    edit1.setText(num1);
                }else if(edit2.isFocused()){
                    num2 = edit2.getText().toString()
                            + numButtons8.getText().toString();
                    edit2.setText(num2);
                }

            }
        });
        numButtons9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edit1.isFocused()){
                    num1 = edit1.getText().toString()
                            + numButtons9.getText().toString();
                    edit1.setText(num1);
                }else if(edit2.isFocused()){
                    num2 = edit2.getText().toString()
                            + numButtons9.getText().toString();
                    edit2.setText(num2);
                }

            }
        });
        */

    }
}