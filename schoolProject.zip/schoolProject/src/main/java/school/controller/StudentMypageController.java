package school.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import school.command.StuPwChangeCommand;
import school.command.StudentCommand;
import school.service.major.MajorListService;
import school.service.student.StuModifyEmailService;
import school.service.stumypage.MypageDetailService;
import school.service.stumypage.StuMypageModifyService;
import school.service.stumypage.StuMypageUpdateService;
import school.service.stumypage.StuPwChangeService;

@Controller
@RequestMapping(value="stuMypage")
public class StudentMypageController {
	@Autowired
	MypageDetailService mypageDetailService;
	@Autowired
	MajorListService majorListService;
	@Autowired
	StuMypageModifyService stuMypageModifyService;
	@Autowired
	StuModifyEmailService stuModifyEmailService;
	@Autowired
	StuMypageUpdateService stuMypageUpdateService;
	@Autowired
	StuPwChangeService stuPwChangeService;
	
	
	@RequestMapping("stuPwChangeCon")
	public String stuPwChangeCon(@Validated StuPwChangeCommand stuPwChangeCommand, BindingResult result, 
								HttpSession session, Model model) {
		String path = stuPwChangeService.execute2(stuPwChangeCommand, result, session, model);
		return path;
	}
	@RequestMapping("stuPwChange")
	public String stuPwChange(@RequestParam(value="stuNum") String stuNum, Model model) {
		stuPwChangeService.execute(stuNum, model);
		return "thymeleaf/stuMypage/stuPwChange";
	}
	@RequestMapping("stuMypageUpdate")
	public String stuMypageUpdate(@Validated StudentCommand studentCommand, BindingResult result, 
									HttpSession session, Model model) {
		Integer i = stuModifyEmailService.execute(studentCommand.getStudentEmail(), studentCommand.getStudentId());
		if (i==1) {
			result.rejectValue("studentEmail", "studentCommand.studentEmail", "존재하는 이메일임띠");
			return "thymeleaf/stuMypage/mypageModify";
		}
		String path= stuMypageUpdateService.execute(studentCommand, session, result, model);
		return path;
	}
	
	@RequestMapping("stuMyPageModify")
	public String stuMyPageModify(@RequestParam(value="id") String id, Model model) {
		stuMypageModifyService.execute(id, model);
		return "thymeleaf/stuMypage/mypageModify";
	}
	
	@RequestMapping("mypageDetail")
	public String mypageDetail(HttpSession session, Model model) {
		mypageDetailService.execute(session, model);
		return "thymeleaf/stuMypage/mypageDetail";
	}
}
