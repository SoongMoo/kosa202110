package school.Command;

import lombok.Data;

@Data
public class DepartmentCommand {
	String departmentNum;
	String departmentName;
	String departmentPhone;
	String depatymentAddr;
}	
