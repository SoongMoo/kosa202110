package school.service.subject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import school.domain.SubjectDTO;
import school.mapper.SubjectMapper;

@Component
@Service
public class SubjectDetailService {
	@Autowired
	SubjectMapper subjectMapper;
	public void execute(String num, Model model) {
		SubjectDTO dto = subjectMapper.selectOne(num);
		model.addAttribute("dto",dto);
	}
	
}
