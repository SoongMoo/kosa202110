package school.service.department;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import school.domain.DepartmentDTO;
import school.mapper.DepartmentMapper;

@Service
public class DepartmentUpdateService {
	@Autowired
	DepartmentMapper departmentMapper;
	public void execute(String num, Model model) {
		DepartmentDTO dto =  departmentMapper.getdepartmentSelectOne(num);
		model.addAttribute("departmentCommand" , dto);
	}

}
