package school.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import school.service.department.DapartmentDeleteService;

@RestController
public class RestControllers{
	@Autowired
	DapartmentDeleteService dapartmentDeleteService;
	
	@RequestMapping("/major/dapartmentDel")
		public String dapartmentDel(@RequestParam(value = "nums")String departmentNum) {

		String i =  dapartmentDeleteService.execute(departmentNum);
		System.out.println("wqetjakdfhaejkrhjakdfhkajrhjkvad"+i);
		return i;
	}
	
}
