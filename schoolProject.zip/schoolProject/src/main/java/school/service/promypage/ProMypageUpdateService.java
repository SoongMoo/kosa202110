package school.service.promypage;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import school.command.ProfessorCommand;
import school.domain.AuthInfo;
import school.domain.ProfessorDTO;
import school.mapper.ProfessorMapper;

@Service
public class ProMypageUpdateService {
	@Autowired
	ProfessorMapper professorMapper;
	@Autowired
	PasswordEncoder passwordEncoder;
	public String execute(ProfessorCommand professorCommand, BindingResult result, HttpSession session, Model model) {
		String path = "redirect:mypageDetail";
		AuthInfo authInfo = (AuthInfo)session.getAttribute("authInfo");
		if (result.hasErrors()) {
			path = "thymeleaf/proMypage/mypageModify";
		}else if(!passwordEncoder.matches(professorCommand.getProfessorPw(), authInfo.getUserPw())) {
			result.rejectValue("professorPw", "professorCommand.professorPw", "비밀번호 틀림띠");
			path = "thymeleaf/proMypage/mypageModify";
		}else {
			ProfessorDTO dto = new ProfessorDTO();
			dto.setProfessorEmail(professorCommand.getProfessorEmail());
			dto.setProfessorId(professorCommand.getProfessorId());
			dto.setProfessorName(professorCommand.getProfessorName());
			dto.setProfessorNum(professorCommand.getProfessorNum());
			dto.setProfessorPhone(professorCommand.getProfessorPhone());
			dto.setDepartmentNum(professorCommand.getDepartmentNum());
			dto.setProfessorPw(professorCommand.getProfessorPw());
			
			professorMapper.professorUpdate(dto);
		}
		return path;
	}

}
