package school.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import school.domain.AuthInfo;
import school.domain.ProfessorDTO;
import school.mapper.LoginMapper;
import school.mapper.ProfessorMapper;

@Component
@Service
public class IdCheckService {
	@Autowired
	ProfessorMapper professorMapper;
	public Integer execute(String professorId) {
		ProfessorDTO dto = professorMapper.proIdCheckService(professorId);
		if (dto!=null) {
			return 1;
		}else {
			return 0;
		}
	}

}
