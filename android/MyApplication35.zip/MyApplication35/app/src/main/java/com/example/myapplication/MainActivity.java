package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    String[] versionArray = new String[] { "젤리빈", "킷켓", "롤리팝" };
    boolean[] checkArray = new boolean[] { true, false, true };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button1 = (Button) findViewById(R.id.button1);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dlg =
                        new AlertDialog.Builder(MainActivity.this);
                //dlg.setTitle("제목입니다");
                //dlg.setMessage("이곳이 내용입니다");
                dlg.setTitle("좋아하는 버전은?");
                dlg.setIcon(R.drawable.ic_launcher);
                dlg.setMultiChoiceItems(versionArray, checkArray,
                        new DialogInterface.OnMultiChoiceClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface,
                                                int i, boolean b) {
                                button1.setText(versionArray[i]);
                            }
                        }
                );

                /*
                dlg.setSingleChoiceItems(versionArray,0,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                button1.setText(versionArray[which]);
                            }
                        });

                 */
                /*
                dlg.setItems(versionArray,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                button1.setText(versionArray[which]);
                            }
                        });
                        */
                /*dlg.setPositiveButton("확인",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(
                                    DialogInterface dialogInterface,
                                    int i) {
                                Toast.makeText(MainActivity.this,
                                        "확인 버튼을 눌렀습니다.",
                                        Toast.LENGTH_SHORT).show();
                            }
                        });
                */
                dlg.setPositiveButton("닫기",null);
                dlg.show();
            }
        });
    }
}