package school.service.professor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import com.google.inject.Binding;

import school.command.ProfessorCommand;
import school.domain.ProfessorDTO;
import school.mapper.ProfessorMapper;

@Component
@Service
public class ProUpdateService {
	@Autowired
	ProfessorMapper professorMapper;
	@Autowired
	PasswordEncoder passwordEncoder;
	
	public void execute(String proNum, Model model) {
		ProfessorDTO dto = professorMapper.selectOne(proNum);
		model.addAttribute("professorCommand", dto);
	}
	public String execute2(ProfessorCommand professorCommand, Model model, BindingResult result) {
		String path = "redirect:proDetail?num="+professorCommand.getProfessorNum();
		ProfessorDTO dto1 = professorMapper.selectOne(professorCommand.getProfessorNum());
		
		if(result.hasErrors()) {
			return "thymeleaf/professor/professorModify";
		}else if(!passwordEncoder.matches(professorCommand.getProfessorPw(), dto1.getProfessorPw())) {
			result.rejectValue("professorPw", "professorCommand.professorPw", "비밀번호가 일치하지 않습니다.");
			return "thymeleaf/professor/professorModify";
		}else {

			ProfessorDTO dto = new ProfessorDTO();
			dto.setProfessorEmail(professorCommand.getProfessorEmail());
			dto.setProfessorId(professorCommand.getProfessorId());
			dto.setProfessorName(professorCommand.getProfessorName());
			dto.setProfessorNum(professorCommand.getProfessorNum());
			dto.setProfessorPhone(professorCommand.getProfessorPhone());
			dto.setDepartmentNum(professorCommand.getDepartmentNum());
			
			professorMapper.professorUpdate(dto);
		}
		
		return path;
	}
}
