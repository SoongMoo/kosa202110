package school.service.student;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import school.mapper.StudentMapper;

@Service
public class StuEmailCheckService {
	@Autowired
	StudentMapper studentMapper;
	public Integer execute(String studentEmail) {
		String exsitEmail = studentMapper.emailDoubleCheck(studentEmail);

		if (exsitEmail!=null) {
			return 1;
		}else return 0;
	}
	
}
