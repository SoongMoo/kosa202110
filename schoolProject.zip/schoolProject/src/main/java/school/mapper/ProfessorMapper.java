package school.mapper;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import school.domain.ProfessorDTO;
import school.domain.StartEndPageDTO;

@Component
@Repository(value="school.mapper.ProfessorMapper")
public interface ProfessorMapper {
	public String autoNum();
	public Integer professorInsert(ProfessorDTO dto);
	public List<ProfessorDTO> selectAll(StartEndPageDTO dto);
	public ProfessorDTO selectOne(String num);
	public Integer professorUpdate(ProfessorDTO dto);
	public Integer professorDelete(String num);
	public ProfessorDTO proEmailCheck(String email);
	public ProfessorDTO proIdCheckService(String id);
	public ProfessorDTO getProOne(String id);
	public ProfessorDTO getDepartName(String num);
	public ProfessorDTO proEmailModiCheck(String email);
	public Integer proPwChange(ProfessorDTO dto);
	public Integer count(String professorWord);
}
