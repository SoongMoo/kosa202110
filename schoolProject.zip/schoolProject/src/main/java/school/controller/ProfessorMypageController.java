package school.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import school.command.ProPwChangeCommand;
import school.command.ProfessorCommand;
import school.service.promypage.ProMypageDetailService;
import school.service.promypage.ProMypageModifyService;
import school.service.promypage.ProMypageUpdateService;
import school.service.promypage.ProPwChangeService;

@Controller
@RequestMapping("proMypage")
public class ProfessorMypageController {
	@Autowired
	ProMypageDetailService proMypageDetailService;
	@Autowired
	ProMypageModifyService proMypageModifyService;
	@Autowired
	ProMypageUpdateService proMypageUpdateService;
	@Autowired
	ProPwChangeService proPwChangeService;
	
	@RequestMapping(value="proPwChangeCon", method = RequestMethod.POST)
	public String proPwChange(@Validated ProPwChangeCommand proPwChangeCommand, BindingResult result,
							HttpSession session, Model model) {
		String path = proPwChangeService.execute2(proPwChangeCommand, result, session, model);
		return path;
	}

	
	@RequestMapping(value="proPwChange", method = RequestMethod.GET)
	public String proPwChange(@RequestParam(value="proNum") String proNum, Model model) {
		proPwChangeService.execute(proNum, model);
		return "thymeleaf/proMypage/proPwChange";
	}
	@RequestMapping("proMypageUpdate")
	public String proMypageUpdate(@Validated ProfessorCommand professorCommand, BindingResult result,
									HttpSession session, Model model) {
		String path= proMypageUpdateService.execute(professorCommand, result, session, model);
		return path;
	}
	@RequestMapping("proMyPageModify")
	public String proMyPageModify(@RequestParam(value="proNum")String num, Model model) {
		proMypageModifyService.execute(num, model);
		return "thymeleaf/proMypage/mypageModify";
	}
	@RequestMapping("mypageDetail")
	public String mypageDetail(Model model, HttpSession session) {
		proMypageDetailService.execute(model, session);
		return "thymeleaf/proMypage/mypageDetail";
	}

}
