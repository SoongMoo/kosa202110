package school.mapper;

import java.util.List;

import org.springframework.stereotype.Repository;

import school.domain.DepartmentDTO;

@Repository(value = "school.mapper.DepartmentMapper")
public interface DepartmentMapper {

	public  String setdmMax();

	public Integer setDepartmentInsert(DepartmentDTO dto);

	public List<DepartmentDTO> getdepartmentSelect();

	public DepartmentDTO getdepartmentSelectOne(String num);

	public Integer setDepartmentUpdate(DepartmentDTO dto);

	public Integer setDepartmentDelete(String departmentNum);

}
