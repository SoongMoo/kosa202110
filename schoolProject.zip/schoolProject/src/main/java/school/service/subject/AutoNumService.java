package school.service.subject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import school.domain.SubjectDTO;
import school.mapper.SubjectMapper;

@Component
@Service
public class AutoNumService {
	@Autowired
	SubjectMapper subjectMapper;
	public void execute(Model model) {
		String autoNum = subjectMapper.autoNum();
		SubjectDTO dto = new SubjectDTO();
		dto.setSubjectNum(autoNum);
		model.addAttribute("auto", autoNum);
	}

}
