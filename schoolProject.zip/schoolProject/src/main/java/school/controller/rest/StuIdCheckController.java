package school.controller.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import school.service.student.StuIdCheckService;

@RestController
public class StuIdCheckController {
	@Autowired
	StuIdCheckService stuIdCheckService;
	
	@RequestMapping(value="/student/stuId")
	public Integer stuId(String stuId) {
		Integer result = stuIdCheckService.execute(stuId);
		return result;
	}
}
