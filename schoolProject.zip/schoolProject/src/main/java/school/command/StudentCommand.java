package school.command;

import javax.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class StudentCommand {

	@NotBlank(message="학과를 선택해야 학번이 자동부여됩니다.")
	String studentNum;
	
	@NotBlank(message="이름을 입력하세요")
	String studentName;

	@NotBlank(message="전화번호를 입력하세요")
	String studentPhone;

	@NotBlank(message="이메일을 입력하세요")
	String studentEmail;

	@NotBlank(message="ID를 입력하세요")
	String studentId;

	@NotBlank(message="Password를 입력하세요")
	String studentPw;
	String studentPwCon;

	@NotBlank(message="학과를 선택하세요")
	String departmentNum;
	
	public boolean pwIsEqualsPwCon(String studentPw ,String studentPwCon) {
		if(studentPw.equals(studentPwCon)) {
			return true;
		}
		
		return false;
	}
	
	String departmentName;
	

}
