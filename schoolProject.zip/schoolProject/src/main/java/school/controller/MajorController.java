package school.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import school.command.MajorCommand;
import school.service.major.MajorAutoNumService;
import school.service.major.MajorDeleteService;
import school.service.major.MajorListService;
import school.service.major.MajorRegistService;
import school.service.major.MajorUpdateService;

@RequestMapping("major")
@Controller
public class MajorController {
	@Autowired 
	MajorRegistService majorRegistService;
	@Autowired
	MajorListService majorListService;
	@Autowired
	MajorAutoNumService majorAutoNumService;
	@Autowired
	MajorUpdateService majorUpdateService;
	@Autowired
	MajorDeleteService majorDeleteService;
	
	@RequestMapping("majorDelete")
	public String majorDelete(@RequestParam (value="num") String num) {
		majorDeleteService.execute(num);
		return "redirect:majorList";
	}
	@RequestMapping("majorUpdate")
	public String majorUpdate(MajorCommand majorCommand) {
		majorUpdateService.execute2(majorCommand);
		return "redirect:majorList";
	}
	@RequestMapping("majorModify")
	public String majorModify(@RequestParam (value="num") String num, Model model) {
		majorUpdateService.execute(num, model);
		return "thymeleaf/major/majorModify";
	}
	
	@RequestMapping("majorRegist")
	public String majorRegist(@Validated MajorCommand majorCommand, BindingResult result) {
		if(result.hasErrors()) {
			return "thymeleaf/major/majorForm";
		}
		majorRegistService.execute(majorCommand);
		return "redirect:majorList";
	}
	@RequestMapping("majorForm")
	public String majorForm(MajorCommand majorCommand, Model model) {
		majorAutoNumService.execute(majorCommand, model);
		return "thymeleaf/major/majorForm";
	}
	
	@RequestMapping("majorList")
	public String majorList(@RequestParam(value = "majorWord" , required = false) String majorWord,
							@RequestParam(value="page", defaultValue = "1", required = false) Integer page,  Model model) {
		majorListService.execute(majorWord, page , model);
		return "thymeleaf/major/majorList";
	}
		
}
	
	

