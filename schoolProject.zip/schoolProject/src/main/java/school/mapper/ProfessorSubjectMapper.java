package school.mapper;

import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;

import school.domain.ProfessorSubjectDTO;
import school.domain.StartEndPageDTO;

@Repository(value="school.mapper.ProSubjectMapper")
public interface ProfessorSubjectMapper {
	public Integer proSubjectInsert (ProfessorSubjectDTO dto);
	public ProfessorSubjectDTO getProNum(String id);
	public List<ProfessorSubjectDTO> selectList(StartEndPageDTO dto);
	public List<ProfessorSubjectDTO> selectList1(String proNum);
	public Integer mySubjectDelete(HashMap<String, String> map);
	public Integer statusUpdateTo1(ProfessorSubjectDTO dto);
	public Integer statusUpdateToNull(ProfessorSubjectDTO dto);
	public String subExist(HashMap< String, String> map);
	public Integer count();
}
