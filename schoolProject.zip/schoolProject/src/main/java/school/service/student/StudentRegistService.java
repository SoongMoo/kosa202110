package school.service.student;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import school.command.StudentCommand;
import school.domain.StudentDTO;
import school.mapper.StudentMapper;
import school.service.major.MajorListService;

@Service
public class StudentRegistService {
	@Autowired
	StudentMapper studentMapper;
	@Autowired
	StudentAutoNumService studentAutoNumService;
	@Autowired
	MajorListService majorListService;
	@Autowired
	PasswordEncoder passwordEncoder;
	
	public void execute(StudentCommand studentCommand, Model model) {

		StudentDTO dto = new StudentDTO();
		dto.setDepartmentNum(studentCommand.getDepartmentNum());
		dto.setStudentEmail(studentCommand.getStudentEmail());
		dto.setStudentId(studentCommand.getStudentId());
		dto.setStudentName(studentCommand.getStudentName());
		dto.setStudentNum(studentCommand.getStudentNum());
		dto.setStudentPhone(studentCommand.getStudentPhone());
		dto.setStudentPw(passwordEncoder.encode(studentCommand.getStudentPw()));
		studentMapper.studentInsert(dto);
		model.addAttribute("dto", dto);
		
	}
	
}
