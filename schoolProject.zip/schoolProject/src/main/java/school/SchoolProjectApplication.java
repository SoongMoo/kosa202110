package school;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

// @repository 나 @service를 찾기 위해 componentscan을 사용한다.
@SpringBootApplication
@ComponentScan(value = "school")
@MapperScan(value = "school")
public class SchoolProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchoolProjectApplication.class, args);
	}

}
