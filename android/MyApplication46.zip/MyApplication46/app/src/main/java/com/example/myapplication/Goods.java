package com.example.myapplication;

public class Goods {
    String goodsNum;
    String goodsName;
    Integer goodsPrice;
    String goodsContent;
    Integer deliveryCost;
    Integer vistCount;

    String goodsImages;
    String goodsOriginal;

    String goodsMain;
    String goodsMainOrg;
}
