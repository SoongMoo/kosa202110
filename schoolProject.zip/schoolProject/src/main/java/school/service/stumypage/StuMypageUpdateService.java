package school.service.stumypage;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import school.command.StudentCommand;
import school.domain.AuthInfo;
import school.domain.StudentDTO;
import school.mapper.StudentMapper;

@Service
public class StuMypageUpdateService {
	@Autowired
	StudentMapper studentMapper;
	@Autowired
	PasswordEncoder passwordEncoder;
	public String execute(StudentCommand studentCommand, HttpSession session, BindingResult result, Model model) {
		AuthInfo authInfo = (AuthInfo)session.getAttribute("authInfo");
		
		String path = "redirect:mypageDetail";
		
		if (result.hasErrors()) {
			path=  "thymeleaf/stuMypage/mypageModify";
		// 비번 틀림
		}else 
		if (!passwordEncoder.matches(studentCommand.getStudentPw(), authInfo.getUserPw())) {
			result.rejectValue("studentPw", "studentCommand.studentPw", "비밀번호 틀림띠");
			path=  "thymeleaf/stuMypage/mypageModify";
		}else {
			StudentDTO dto = new StudentDTO();
			dto.setDepartmentNum(studentCommand.getDepartmentNum());
			dto.setStudentEmail(studentCommand.getStudentEmail());
			dto.setStudentName(studentCommand.getStudentName());
			dto.setStudentPhone(studentCommand.getStudentPhone());
			dto.setStudentPw(passwordEncoder.encode(studentCommand.getStudentPw()));
			dto.setStudentNum(studentCommand.getStudentNum());
			dto.setStudentId(studentCommand.getStudentId());
			studentMapper.studentUpdate(dto);
		}
		return path;
		
	}
	
}
