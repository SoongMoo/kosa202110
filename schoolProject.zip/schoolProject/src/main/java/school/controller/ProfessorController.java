package school.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import school.command.ProfessorCommand;
import school.service.EmailCheckService;
import school.service.IdCheckService;
import school.service.major.MajorListService;
import school.service.professor.ProDeleteService;
import school.service.professor.ProDetailService;
import school.service.professor.ProEmailCheckService;
import school.service.professor.ProListService;
import school.service.professor.ProUpdateService;
import school.service.professor.ProRegistService;
import school.service.professor.ProfessorAutoNumService;


@RequestMapping("professor")
@Controller
public class ProfessorController {
	@Autowired
	ProfessorAutoNumService professorAutoNumService;
	@Autowired
	ProRegistService proRegistService;
	@Autowired
	MajorListService majorListService;
	@Autowired
	ProListService proListService;
	@Autowired
	ProDetailService proDetailService;
	@Autowired
	ProUpdateService proUpdateService;
	@Autowired
	ProDeleteService proDeleteService;
	@Autowired
	IdCheckService idCheckService;
	@Autowired
	EmailCheckService emailCheckService;
	@Autowired
	ProEmailCheckService proEmailCheckService;
	
	
	@RequestMapping("professorDelete")
	public String professorDelete(@RequestParam(value="proNum") String num) {
		proDeleteService.execute(num);
		return "redirect:professorList";
	}
	@RequestMapping("professorUpdate")
	public String professorUpdate(@RequestParam(value="page", defaultValue = "1", required = false) Integer page, 
									@Validated ProfessorCommand professorCommand, BindingResult result, Model model,
									@RequestParam(value = "majorWord" , required = false)String majorWord) {
		majorListService.execute(majorWord, page, model);
		String path = "redirect:proDetail?num="+professorCommand.getProfessorNum();
		Integer i = proEmailCheckService.execute(professorCommand.getProfessorEmail(), professorCommand.getProfessorId());
		if(i==1) {
			result.rejectValue("professorEmail", "professorCommand.professorEmail", "이미 사용중인 이메일입니다.");
			return "thymeleaf/professor/professorModify";
		}

		path = proUpdateService.execute2(professorCommand, model, result);
		return path;
	}
	@RequestMapping("professorModify")
	public String professorModify(@RequestParam(value="page", defaultValue = "1", required = false) Integer page, 
								  @RequestParam(value="proNum") String num, Model model,
								  @RequestParam(value = "majorWord" , required = false)String majorWord) {
		majorListService.execute(majorWord,page, model);
		proUpdateService.execute(num, model);
		return "thymeleaf/professor/professorModify";
	}
	@RequestMapping("proDetail")
	public String proDetail(@RequestParam(value="num") String num, Model model) {
		proDetailService.execute(num, model);
		return "thymeleaf/professor/professorDetail";
	}
	@RequestMapping("professorRegist")
	public String professorRegist(@RequestParam(value="page", defaultValue = "1", required = false) Integer page, 
								  @Validated ProfessorCommand professorCommand, BindingResult result, Model model,
								  @RequestParam(value = "majorWord" , required = false)String majorWord) {
		majorListService.execute(majorWord,page, model);
		if(!professorCommand.pwIsEqualsPwCon(professorCommand.getProfessorPw() , professorCommand.getProfessorPwCon())) {
			result.rejectValue("professorPwCon", "professorPwCommand.professorPwCon", 
					"비밀번호확인이 틀립니다.");
			return "thymeleaf/professor/professorForm";
		}
		if(result.hasErrors()) {
			return "thymeleaf/professor/professorForm";
		}
		
		Integer i = idCheckService.execute(professorCommand.getProfessorId());
		if(i==1) {
			result.rejectValue("professorId", "professorCommand.professorId", "이미 사용중인 아이디입니다.");
			return "thymeleaf/professor/professorForm";
		}
		
		i = emailCheckService.execute(professorCommand.getProfessorEmail());
		if(i==1) {
			result.rejectValue("professorEmail", "professorCommand.professorEmail", "이미 사용중인 이메일입니다.");
			return "thymeleaf/professor/professorForm";
		}
		
		
		proRegistService.execute(professorCommand);
		return "redirect:professorList";
	}
	@RequestMapping("professorForm")
	public String professorForm(@RequestParam(value="page", defaultValue = "1", required = false) Integer page, 
								Model model, ProfessorCommand professorCommand,
								@RequestParam(value = "majorWord" , required = false)String majorWord) {
		majorListService.execute(majorWord,page, model);
		professorAutoNumService.execute(professorCommand);
		return "thymeleaf/professor/professorForm";
	}
	@RequestMapping("professorList")
	public String professorList(@RequestParam(value="page", defaultValue = "1", required = false) Integer page, Model model,
								@RequestParam(value="professorWord", required = false) String professorWord) {
		proListService.execute(professorWord, page, model);
		return "thymeleaf/professor/professorList";
	}
}
