package school.controller.major;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import school.Command.DepartmentCommand;
import school.service.department.DepartmentListService;
import school.service.department.DepartmentMaxService;
import school.service.department.DepartmentModifyService;
import school.service.department.DepartmentUpdateService;
import school.service.department.DepartmentWriteService;

@Controller
@RequestMapping("major")
public class DepartmentController {
	@Autowired
	DepartmentMaxService departmentMaxService;
	@Autowired
	DepartmentWriteService departmentWriteService;
	@Autowired
	DepartmentListService departmentListService;
	@Autowired
	DepartmentUpdateService departmentUpdateService;
	@Autowired
	DepartmentModifyService departmentModifyService;
	
	
	@RequestMapping(value = "departmentUpdate" , method = RequestMethod.POST)
	public String departmentUpdate1(DepartmentCommand departmentCommand , HttpServletResponse response) {
		departmentModifyService.execute(departmentCommand);
		try {
			response.setContentType("text/html; charset=utf-8"); 
			PrintWriter out = response.getWriter();
			String str=  "<script language='javascript'>" 
			          +  "opener.location.reload();"
			          + "				window.self.close();"
			          + "</script>";
			 out.print(str);
			 out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	@RequestMapping(value = "departmentUpdate" , method = RequestMethod.GET)
	public String departmentUpdate(@RequestParam(value = "num")String num , Model model) {
		departmentUpdateService.execute(num , model);
		return "thymeleaf/major/departmentUpdate";
	}
	
	@RequestMapping(value = "departmentWrite" ,method = RequestMethod.POST)
	public String departmentWrite1(DepartmentCommand departmentCommand) {
		departmentWriteService.execute(departmentCommand);
		return "redirect:majorList";
	}
	
	
	@RequestMapping(value = "departmentWrite" ,method = RequestMethod.GET)
	public String departmentWrite(Model model) {
		departmentMaxService.execute(model);
		return "thymeleaf/major/departmentWrite";
	}
	
	
	@RequestMapping("majorList")
	public String majorList(Model model) {
		departmentListService.execute(model);
		return "thymeleaf/major/majorList";
	}
	
	
}
