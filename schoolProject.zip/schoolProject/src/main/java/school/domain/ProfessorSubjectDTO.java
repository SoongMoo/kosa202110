package school.domain;

import lombok.Data;

@Data
public class ProfessorSubjectDTO {
	String professorNum;
	String subjectNum;
	String subjectName;
	char status;
	
}
