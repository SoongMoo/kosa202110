package school.command;

import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
public class MajorCommand {
	String majorNum;
	
	@NotBlank(message = "이름을 입력하세요.")
	String majorName;
	
	@NotBlank(message = "전화번호를 입력하세요.")
	String majorPhone;
	
	@NotBlank(message = "주소를 입력하세요.")
	String majorAddr;
	
	@NotBlank(message = "우편번호를 입력하세요.")
	String zip;
	
	@NotBlank(message = "주소를 입력하세요.")
	String addr1;
	
	@NotBlank(message = "주소를 입력하세요.")
	String addr2;
	
	@NotBlank(message = "주소를 입력하세요.")
	String fullAddr;
	
}
